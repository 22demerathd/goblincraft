		- Blank pack -
		Custom models

This pack contains a few files to help you create custom models.

Tips :
	- You can use custom_model_data for blocks, but only for their model in the inventory ("item" folder)
	- Be careful, custom_model_data doesn't support a 0 at the start (01200007 is not a valid data)